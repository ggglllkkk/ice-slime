import pygame
from pygame.locals import *
import manager
from player import Player

pygame.init()
pygame.key.set_repeat(200,100)
screen = pygame.display.set_mode((800,450), RESIZABLE)

player = Player()

def keyEventsManager(event):
    toDo = {"up":player.up, "down":player.down, "left":player.left, "right":player.right}
    dico=manager.getKeys()
    if event.dict["unicode"] in dico.keys(): toDo[dico[event.dict["unicode"]]]()
    return
        
def drawAll():
    screen.fill((0,0,0))
    screen.blit(player.image, (player.rect.x, player.rect.y))
    return

doContinue = True
while doContinue:
    for event in pygame.event.get():
        if event.type == QUIT:
            doContinue = False
        if event.type == KEYDOWN:
            keyEventsManager(event)
    
    drawAll()
    pygame.display.flip()

pygame.quit()