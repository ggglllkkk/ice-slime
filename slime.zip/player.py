import pygame

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        self.image = pygame.image.load("data/player.png")
        self.rect = self.image.get_rect()
        self.speed = 5

    def up(self):self.rect.y-=self.speed
    def down(self):self.rect.y+=self.speed
    def left(self):self.rect.x-=self.speed
    def right(self):self.rect.x+=self.speed